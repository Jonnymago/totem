import React, { useCallback, useEffect, useState } from 'react';
import {
  View,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Switch,
  ActivityIndicator,
  Alert,
  Share,
  Platform,
  Modal,
  useWindowDimensions,
} from 'react-native';
import { Image as ExpoImage } from 'expo-image';
import { Ionicons } from '@expo/vector-icons';
import { useRouter } from 'expo-router';
import * as Clipboard from 'expo-clipboard';
import * as WebBrowser from 'expo-web-browser';
import {
  getSettings,
  updateSettings,
  getProducts,
  updateProduct,
  getRemoteAdminUrl,
  getCategories,
  upsertSignageScreen,
  deleteSignageScreen,
  getSignageSettings,
  updateSignageSettings,
  DigitalSignageSettings,
  SignageCategoryConfig,
  SignageProductConfig,
  Product,
  Category,
  SignageScreen,
} from '@/src/api/api';
import { Text, TextInput, InfoTip } from '@/src/components/LocalizedPrimitives';
import { useI18n } from '@/src/utils/i18n';
import { sanitizeImageUri } from '@/src/utils/imageUtils';
import { getFastLocalIp } from '@/src/utils/lanScanner';
import AdminHeader from '@/src/components/AdminHeader';

const TEMPLATE_PRESETS = [
  { id: 'chalkboard', label: 'Lavagna Bistrot', icon: 'tablet-landscape', desc: 'Stile ardesia rustico per hamburgerie e pub' },
  { id: 'fastfood-vibrant', label: 'Fast Food Vibrant', icon: 'fast-food', desc: 'Rosso & Giallo ad alto impatto visivo' },
  { id: 'dark-gold', label: 'Luxury Dark Gold', icon: 'sparkles', desc: 'Nero profondo e oro per sushi & gourmet' },
  { id: 'trattoria', label: 'Pizzeria & Forno', icon: 'pizza', desc: 'Toni caldi terracotta e tradizione italiana' },
  { id: 'fresh-emerald', label: 'Fresh Poke & Bio', icon: 'leaf', desc: 'Verde smeraldo per insalate e cibi sani' },
  { id: 'steakhouse', label: 'Steakhouse & Braci', icon: 'flame', desc: 'Fumo, brace e carni selezionate' },
  { id: 'cyberpunk-neon', label: 'Cyberpunk Neon', icon: 'flash', desc: 'Viola fluo e ciano per lounge bar e street food' },
  { id: 'nordic-minimal', label: 'Nordic Minimal', icon: 'snow', desc: 'Bianco puro e nero scandinavo per bakery e caffè' },
  { id: 'sunset-coral', label: 'Sunset Coral', icon: 'sunny', desc: 'Arancio caldo e corallo per messicano e aperitivi' },
];

const TRANSITIONS = [
  { id: 'curtain-slide', label: 'Curtain Slide', icon: 'play-forward' },
  { id: 'fade-blur', label: 'Fade Morbido', icon: 'color-wand' },
  { id: 'zoom-in', label: 'Zoom In Cinema', icon: 'scan' },
  { id: 'flip-3d', label: 'Flip 3D Card', icon: 'cube' },
  { id: 'ken-burns', label: 'Ken Burns Pan', icon: 'videocam' },
  { id: 'slide-left', label: 'Scorrimento Laterale', icon: 'arrow-forward' },
];

const LAYOUT_OPTIONS = [
  { id: 'auto', label: 'Auto (Ottimale)', desc: 'Adatta la griglia in base ai piatti' },
  { id: 'grid-all', label: 'Tutti i Prodotti (Auto-Grid)', desc: 'Mostra l\'intera categoria nella pagina' },
  { id: 'list-table', label: 'Listino a Tabella (Menu Fisso)', desc: 'Righe compatte con nome, descrizione e prezzo' },
  { id: 'hero-1', label: '1 Piatto Gigante (Mega Hero)', desc: 'Focus totale su 1 piatto speciale' },
  { id: 'grid-2', label: '2 Piatti Grandi (Hero Duo)', desc: '2 piatti a tutto schermo' },
  { id: 'grid-3', label: '3 Piatti (1 Hero + 2)', desc: '1 piatto grande a sinistra + 2 a destra' },
  { id: 'grid-4', label: '4 Card 2x2', desc: '4 piatti grandi bilanciati' },
  { id: '1-hero-4-grid', label: '1 Hero + 4 Griglia', desc: '1 grande piatto a sinistra + 4 a destra' },
  { id: '2-hero-2-grid', label: '2 Hero + 2 Griglia', desc: '2 piatti grandi sopra + 2 sotto' },
  { id: 'bento', label: 'Bento Grid Moderno', desc: 'Composizione asimmetrica moderna' },
  { id: 'grid-6', label: '6 Card Cinema (3x2)', desc: '6 piatti a tutto schermo' },
  { id: 'grid-8', label: '8 Card Menu Completo (4x2)', desc: 'Massima densità informativa' },
  { id: 'grid-10', label: '10 Card Alta Densità (5x2)', desc: 'Ideale per drink, birre e dessert' },
  { id: 'grid-12', label: '12 Card Panorama (6x2)', desc: 'Per cataloghi ampi su monitor 4K' },
  { id: 'grid-16', label: '16 Card Ultra Densità (4x4)', desc: 'Listino completo a colpo d\'occhio' },
  { id: 'hero-spotlight', label: 'Spotlight Singolo', desc: '1 piatto gigante con riflettori' },
];

const FONT_OPTIONS = [
  { id: 'impact', label: 'Impact / Bold', desc: 'Lettere spesse e visibili da lontano' },
  { id: 'sans', label: 'Modern Sans', desc: 'Pulito, moderno e ad alta leggibilità' },
  { id: 'serif', label: 'Classico Serif', desc: 'Elegante per ristoranti gourmet' },
  { id: 'slab', label: 'Western Slab', desc: 'Rustico per bracerie e pub' },
];

const ANIMATION_OPTIONS = [
  { id: 'ken-burns', label: '🎥 Ken Burns Zoom', desc: 'Zoom & Pan lento continuo sull\'immagine' },
  { id: 'pulse-glow', label: '💓 Food-Porn Pulse', desc: 'Luce calda pulsante e accento dinamico' },
  { id: 'steam-float', label: '☁️ Steam Vapore', desc: 'Onde morbide ideali per cibi caldi' },
  { id: 'price-shimmer', label: '✨ Price Shimmer', desc: 'Riflesso dorato continuo sul prezzo' },
  { id: '3d-pop', label: '🧊 3D Pop Depth', desc: 'Effetto tridimensionale fluttuante' },
  { id: 'none', label: '⏹️ Nessuna', desc: 'Card statica standard' },
];

const BADGE_PRESETS = [
  '🔥 PIÙ VENDUTO',
  '★ CONSIGLIO CHEF',
  '⭐ SPECIALITÀ',
  '✨ NOVITÀ DEL MESE',
  '🍔 PROMO COMBO',
  '🍕 FORNO A LEGNA',
  '🌱 VEGAN / BIO',
  '🌾 GLUTEN FREE',
];

export default function DigitalSignageScreen() {
  const router = useRouter();
  useI18n();
  const { width: winW } = useWindowDimensions();
  const isTablet = winW >= 768;

  const [saving, setSaving] = useState(false);
  const [refreshingCatalog, setRefreshingCatalog] = useState(false);
  const [localIp, setLocalIp] = useState('');
  const [products, setProducts] = useState<Product[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [screens, setScreens] = useState<SignageScreen[]>([]);
  const [selectedCatId, setSelectedCatId] = useState<string>('');
  const [togglingProdId, setTogglingProdId] = useState<string | null>(null);

  // Digital Signage Studio State
  const [editorOpen, setEditorOpen] = useState(false);
  const [activePreviewCatIndex, setActivePreviewCatIndex] = useState(0);
  const [previewPlaying, setPreviewPlaying] = useState(true);

  const [signageConfig, setSignageConfig] = useState<DigitalSignageSettings>({
    rotate_seconds: 8,
    ticker_enabled: true,
    ticker_text: '🍟 MENÙ SPECIALE DEL GIORNO • Ingredienti freschi e selezionati ogni mattina • Chiedi al personale!',
    default_theme: 'chalkboard',
    default_transition: 'curtain-slide',
    auto_reorganize_unavailable: true,
    show_queue_bar: true,
    columns: 4,
    mode: 'full',
    tv_orientation: 'landscape',
    products_per_page: 'all',
    video_loop_enabled: false,
    video_loop_url: '',
    video_loop_opacity: 0.85,
    video_loop_fit: 'cover',
    video_loop_muted: true,
    categories_config: {},
  });

  const load = useCallback(async () => {
    try {
      const [data, catalog, cats, fastIp, studioCfg] = await Promise.all([
        getSettings(),
        getProducts().catch(() => [] as Product[]),
        getCategories().catch(() => [] as Category[]),
        getFastLocalIp(1200),
        getSignageSettings().catch(() => null),
      ]);
      setProducts(catalog || []);
      setCategories(cats || []);
      setScreens(data.signage_screens || []);
      if (cats && cats.length > 0 && !selectedCatId) {
        setSelectedCatId(cats[0].id);
      }
      if (fastIp) setLocalIp(fastIp);
      if (studioCfg) {
        setSignageConfig((prev) => ({
          ...prev,
          ...studioCfg,
          tv_orientation: studioCfg.tv_orientation || 'landscape',
          products_per_page: studioCfg.products_per_page || 'all',
          video_loop_opacity: studioCfg.video_loop_opacity ?? 0.85,
          video_loop_fit: studioCfg.video_loop_fit || 'cover',
          video_loop_muted: studioCfg.video_loop_muted !== false,
        }));
      }
    } catch (e) {
      console.warn('signage load', e);
    }
  }, [selectedCatId]);

  useEffect(() => { void load(); }, [load]);

  const handleRefreshProductsAndBackup = async () => {
    try {
      setRefreshingCatalog(true);
      const [prods, cats, fastIp] = await Promise.all([
        getProducts(true),
        getCategories(),
        getFastLocalIp(1000),
      ]);
      setProducts(prods || []);
      setCategories(cats || []);
      if (fastIp) setLocalIp(fastIp);
      Alert.alert('✅ Catalogo Aggiornato', `Sincronizzati con successo ${prods.length} prodotti e ${cats.length} categorie per il Digital Signage.`);
    } catch (e: any) {
      Alert.alert('Errore sincronizzazione', e?.message || 'Impossibile ricaricare i prodotti.');
    } finally {
      setRefreshingCatalog(false);
    }
  };

  const getTvUrl = (orientation?: 'landscape' | 'portrait') => {
    const orient = orientation || signageConfig.tv_orientation || 'landscape';
    const remote = getRemoteAdminUrl();
    if (remote && !remote.includes('localhost') && !remote.includes('127.0.0.1')) {
      const base = remote.replace(/\/admin\/?.*$/, '');
      return `${base}/display/tv?orientation=${orient}`;
    }
    const ip = localIp || '192.168.1.XXX';
    return `http://${ip}:3000/display/tv?orientation=${orient}`;
  };

  const handleSave = async () => {
    try {
      setSaving(true);
      await Promise.all([
        updateSignageSettings(signageConfig),
        updateSettings({
          signage_screens: screens,
        }),
      ]);
      Alert.alert('✅ Configurazione Salvata', 'Lo Studio Digital Signage è stato aggiornato. I monitor TV rifletteranno le modifiche all\'istante.');
    } catch (e: any) {
      Alert.alert('Errore', e?.message || 'Impossibile salvare la configurazione.');
    } finally {
      setSaving(false);
    }
  };

  const copyUrl = async (url?: string) => {
    const value = url || getTvUrl();
    await Clipboard.setStringAsync(value);
    Alert.alert('Link Copiato', `Indirizzo TV copiato negli appunti:\n${value}`);
  };

  const updateCatConfig = (catId: string, patch: Partial<SignageCategoryConfig>) => {
    setSignageConfig((prev) => {
      const existing = prev.categories_config?.[catId] || { category_id: catId };
      const next = { ...existing, ...patch };
      return {
        ...prev,
        categories_config: {
          ...(prev.categories_config || {}),
          [catId]: next,
        },
      };
    });
  };

  const updateProdConfig = (catId: string, prodId: string, patch: Partial<SignageProductConfig>) => {
    setSignageConfig((prev) => {
      const catCfg = prev.categories_config?.[catId] || { category_id: catId };
      const prodCfgs = catCfg.products_config || {};
      const existing = prodCfgs[prodId] || { product_id: prodId };
      const nextProd = { ...existing, ...patch };
      const nextCat: SignageCategoryConfig = {
        ...catCfg,
        products_config: {
          ...prodCfgs,
          [prodId]: nextProd,
        },
      };
      return {
        ...prev,
        categories_config: {
          ...(prev.categories_config || {}),
          [catId]: nextCat,
        },
      };
    });
  };

  const toggleProductAvailable = async (product: Product) => {
    try {
      setTogglingProdId(product.id);
      const next = product.available === false ? true : false;
      await updateProduct(product.id, { available: next });
      setProducts((prev) => prev.map((p) => (p.id === product.id ? { ...p, available: next } : p)));
    } catch (e: any) {
      Alert.alert('Errore', e?.message || 'Impossibile aggiornare la disponibilità.');
    } finally {
      setTogglingProdId(null);
    }
  };

  const currentCategory = categories.find((c) => c.id === selectedCatId) || categories[0];
  const currentCatConfig: SignageCategoryConfig = (currentCategory && signageConfig.categories_config?.[currentCategory.id]) || {
    category_id: currentCategory?.id || '',
    enabled: true,
    duration_seconds: 8,
    layout: 'auto',
    theme: 'chalkboard',
    transition: 'curtain-slide',
    products_config: {},
  };

  const prodsForCurrentCat = products.filter((p) => currentCategory && String(p.category_id) === String(currentCategory.id));
  const tvUrl = getTvUrl();
  const isPortrait = signageConfig.tv_orientation === 'portrait';

  return (
    <View style={styles.container}>
      <AdminHeader
        title="Digital Signage TV"
        subtitle="Regia monitor sala, orientamento verticale/orizzontale, video loop e cataloghi completi"
        emoji="📺"
        showBack={true}
        showTotemButton={true}
        badge={{
          text: isPortrait ? 'TV Verticale (9:16)' : 'TV Orizzontale (16:9)',
          variant: 'primary',
        }}
        rightActions={
          <View style={{ flexDirection: 'row', gap: 6 }}>
            <TouchableOpacity
              style={styles.headerSyncBtn}
              onPress={handleRefreshProductsAndBackup}
              disabled={refreshingCatalog}
            >
              {refreshingCatalog ? (
                <ActivityIndicator size="small" color="#0F766E" />
              ) : (
                <Ionicons name="refresh-outline" size={16} color="#0F766E" />
              )}
              <Text style={styles.headerSyncBtnText}>Aggiorna Prodotti</Text>
            </TouchableOpacity>

            <TouchableOpacity style={styles.headerSaveBtn} onPress={handleSave} disabled={saving}>
              {saving ? <ActivityIndicator color="#fff" size="small" /> : <Ionicons name="save-outline" size={16} color="#fff" />}
              <Text style={styles.headerSaveBtnText}>{saving ? 'Salvataggio...' : 'Salva'}</Text>
            </TouchableOpacity>
          </View>
        }
      />

      <ScrollView style={styles.content} contentContainerStyle={styles.scroll} keyboardShouldPersistTaps="handled">
        {/* BIG STUDIO LAUNCH CARD */}
        <TouchableOpacity style={styles.btnOpenStudio} onPress={() => setEditorOpen(true)}>
          <View style={styles.btnOpenStudioLeft}>
            <View style={styles.studioIconCircle}>
              <Ionicons name="videocam" size={26} color="#FFF" />
            </View>
            <View style={{ flex: 1 }}>
              <Text style={styles.btnOpenStudioTitle}>🎬 Apri Studio Regia TV & Anteprima Live</Text>
              <Text style={styles.btnOpenStudioSubtitle}>
                Orientamento TV (Orizzontale / Verticale), rotazione categorie, layout con tutti i prodotti e video in loop.
              </Text>
            </View>
          </View>
          <Ionicons name="chevron-forward" size={24} color="#FFF" />
        </TouchableOpacity>

        {/* TV ORIENTATION & PAGINATION QUICK CARD */}
        <View style={styles.card}>
          <View style={styles.cardHead}>
            <Ionicons name="crop-outline" size={20} color="#0F766E" />
            <Text style={styles.cardTitle}>Orientamento Display TV & Paginazione Prodotti</Text>
          </View>

          {/* Orientation Selector */}
          <Text style={styles.label}>Orientamento Schermo TV:</Text>
          <View style={{ flexDirection: 'row', gap: 10 }}>
            {[
              { id: 'landscape', label: '🖥️ Orizzontale Standard (16:9)', desc: 'TV classiche a parete / bancone' },
              { id: 'portrait', label: '📱 Verticale Totem (9:16)', desc: 'Display a colonna / totem verticale' },
            ].map((or) => {
              const active = (signageConfig.tv_orientation || 'landscape') === or.id;
              return (
                <TouchableOpacity
                  key={or.id}
                  style={[styles.orientBtn, active && styles.orientBtnActive]}
                  onPress={() => setSignageConfig({ ...signageConfig, tv_orientation: or.id as any })}
                >
                  <Text style={[styles.orientBtnText, active && styles.orientBtnTextActive]}>{or.label}</Text>
                  <Text style={[styles.orientBtnDesc, active && styles.orientBtnDescActive]}>{or.desc}</Text>
                </TouchableOpacity>
              );
            })}
          </View>

          {/* Products per Page Selector */}
          <Text style={[styles.label, { marginTop: 10 }]}>Numero Prodotti per Slide / Pagina Categoria:</Text>
          <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>
            {[
              { id: 'all', label: 'Tutti i Prodotti della Categoria (Auto-Grid)' },
              { id: '4', label: '4 Prodotti' },
              { id: '6', label: '6 Prodotti' },
              { id: '8', label: '8 Prodotti' },
              { id: '2', label: '2 Grandi (Hero Duo)' },
            ].map((opt) => {
              const active = String(signageConfig.products_per_page || 'all') === opt.id;
              return (
                <TouchableOpacity
                  key={opt.id}
                  style={[styles.smallPill, active && styles.smallPillActive]}
                  onPress={() => setSignageConfig({ ...signageConfig, products_per_page: opt.id as any })}
                >
                  <Text style={[styles.smallPillText, active && styles.smallPillTextActive]}>{opt.label}</Text>
                </TouchableOpacity>
              );
            })}
          </View>
        </View>

        {/* BACKGROUND VIDEO LOOP SETTINGS */}
        <View style={styles.card}>
          <View style={styles.cardHead}>
            <Ionicons name="film-outline" size={20} color="#E11D48" />
            <Text style={styles.cardTitle}>Video in Loop di Sfondo (Food-Porn & Atmosfera)</Text>
          </View>

          <View style={styles.row}>
            <View style={{ flex: 1 }}>
              <Text style={styles.rowTitle}>Abilita Video in Background</Text>
              <Text style={styles.hint}>Riproduce un video fluido in loop continuo sotto al menu dei prodotti</Text>
            </View>
            <Switch
              value={Boolean(signageConfig.video_loop_enabled)}
              onValueChange={(v) => setSignageConfig({ ...signageConfig, video_loop_enabled: v })}
              trackColor={{ false: '#CBD5E1', true: '#E11D48' }}
            />
          </View>

          {signageConfig.video_loop_enabled && (
            <View style={{ gap: 10, marginTop: 8 }}>
              <View>
                <Text style={styles.label}>URL Video in Loop (MP4 o WebM):</Text>
                <TextInput
                  style={styles.input}
                  value={signageConfig.video_loop_url || ''}
                  onChangeText={(t) => setSignageConfig({ ...signageConfig, video_loop_url: t })}
                  placeholder="https://assets.mixkit.co/videos/preview/mixkit-top-view-of-a-table-full-of-food-41728-large.mp4"
                />
              </View>

              <View style={{ flexDirection: 'row', gap: 12 }}>
                <View style={{ flex: 1 }}>
                  <Text style={styles.label}>Opacità Video ({Math.round((signageConfig.video_loop_opacity ?? 0.85) * 100)}%):</Text>
                  <View style={{ flexDirection: 'row', gap: 6 }}>
                    {[0.3, 0.5, 0.85, 1.0].map((op) => {
                      const active = (signageConfig.video_loop_opacity ?? 0.85) === op;
                      return (
                        <TouchableOpacity
                          key={op}
                          style={[styles.smallPill, active && styles.smallPillActive]}
                          onPress={() => setSignageConfig({ ...signageConfig, video_loop_opacity: op })}
                        >
                          <Text style={[styles.smallPillText, active && styles.smallPillTextActive]}>
                            {Math.round(op * 100)}%
                          </Text>
                        </TouchableOpacity>
                      );
                    })}
                  </View>
                </View>

                <View style={{ flex: 1 }}>
                  <Text style={styles.label}>Adattamento Video:</Text>
                  <View style={{ flexDirection: 'row', gap: 6 }}>
                    {[
                      { id: 'cover', label: 'Cover (Pieno)' },
                      { id: 'contain', label: 'Contain' },
                    ].map((fit) => {
                      const active = (signageConfig.video_loop_fit || 'cover') === fit.id;
                      return (
                        <TouchableOpacity
                          key={fit.id}
                          style={[styles.smallPill, active && styles.smallPillActive]}
                          onPress={() => setSignageConfig({ ...signageConfig, video_loop_fit: fit.id as any })}
                        >
                          <Text style={[styles.smallPillText, active && styles.smallPillTextActive]}>{fit.label}</Text>
                        </TouchableOpacity>
                      );
                    })}
                  </View>
                </View>
              </View>
            </View>
          )}
        </View>

        {/* Live TV Connection & QR Box */}
        <View style={styles.card}>
          <View style={styles.cardHead}>
            <Ionicons name="tv-outline" size={20} color="#16A34A" />
            <Text style={styles.cardTitle}>Collegamento Monitor TV / Firestick</Text>
          </View>
          <Text style={styles.url}>{tvUrl}</Text>
          {localIp ? (
            <ExpoImage
              source={{ uri: `https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=${encodeURIComponent(tvUrl)}` }}
              style={styles.qrCode}
              contentFit="contain"
            />
          ) : null}
          <View style={styles.urlActionsRow}>
            <TouchableOpacity style={styles.ghost} onPress={() => { void copyUrl(); }}>
              <Ionicons name="copy-outline" size={15} color="#1E293B" />
              <Text style={styles.ghostText}>Copia URL</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.ghost} onPress={() => { void Share.share({ message: tvUrl }).catch(() => {}); }}>
              <Ionicons name="share-social-outline" size={15} color="#1E293B" />
              <Text style={styles.ghostText}>Condividi</Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={[styles.ghost, { borderColor: '#E11D48' }]}
              onPress={() => {
                if (Platform.OS === 'web') {
                  window.open(tvUrl, '_blank');
                } else {
                  void WebBrowser.openBrowserAsync(tvUrl);
                }
              }}
            >
              <Ionicons name="open-outline" size={15} color="#E11D48" />
              <Text style={[styles.ghostText, { color: '#E11D48' }]}>Apri Anteprima TV</Text>
            </TouchableOpacity>
          </View>
        </View>

        {/* GLOBAL TIMELINE & THEME SETTINGS */}
        <View style={styles.card}>
          <View style={styles.cardHead}>
            <Ionicons name="options-outline" size={20} color="#0284C7" />
            <Text style={styles.cardTitle}>Impostazioni Globali Regia</Text>
          </View>

          {/* Theme selection */}
          <Text style={styles.label}>Tema Grafico Predefinito</Text>
          <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ gap: 8, paddingVertical: 4 }}>
            {TEMPLATE_PRESETS.map((t) => {
              const isSel = (signageConfig.default_theme || 'chalkboard') === t.id;
              return (
                <TouchableOpacity
                  key={t.id}
                  style={[styles.themePill, isSel && styles.themePillActive]}
                  onPress={() => setSignageConfig({ ...signageConfig, default_theme: t.id as any })}
                >
                  <Ionicons name={t.icon as any} size={16} color={isSel ? '#FFF' : '#334155'} />
                  <Text style={[styles.themePillText, isSel && styles.themePillTextActive]}>{t.label}</Text>
                </TouchableOpacity>
              );
            })}
          </ScrollView>

          {/* Font Family selection */}
          <Text style={[styles.label, { marginTop: 10 }]}>Carattere Tipografico (Font)</Text>
          <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 6 }}>
            {FONT_OPTIONS.map((f) => {
              const isSel = (signageConfig.font_family || 'impact') === f.id;
              return (
                <TouchableOpacity
                  key={f.id}
                  style={[styles.smallPill, isSel && styles.smallPillActive]}
                  onPress={() => setSignageConfig({ ...signageConfig, font_family: f.id as any })}
                >
                  <Text style={[styles.smallPillText, isSel && styles.smallPillTextActive]}>{f.label}</Text>
                </TouchableOpacity>
              );
            })}
          </View>

          {/* Show Product Descriptions Toggle */}
          <View style={[styles.row, { marginTop: 10 }]}>
            <View style={{ flex: 1 }}>
              <Text style={styles.rowTitle}>Mostra Descrizioni Piatti su TV</Text>
              <Text style={styles.hint}>Visualizza ingredienti e dettagli sotto il titolo di ogni piatto</Text>
            </View>
            <Switch
              value={Boolean(signageConfig.show_product_descriptions)}
              onValueChange={(v) => setSignageConfig({ ...signageConfig, show_product_descriptions: v })}
              trackColor={{ false: '#CBD5E1', true: '#0F766E' }}
            />
          </View>

          {/* Rotation speed */}
          <View style={[styles.row, { marginTop: 10 }]}>
            <View style={{ flex: 1 }}>
              <Text style={styles.rowTitle}>Durata Slide Categorie (Secondi)</Text>
              <Text style={styles.hint}>Tempo di permanenza di ciascuna schermata prima di passare alla successiva</Text>
            </View>
            <View style={{ flexDirection: 'row', gap: 6 }}>
              {[4, 6, 8, 10, 12, 15, 20].map((sec) => (
                <TouchableOpacity
                  key={sec}
                  style={[styles.secPill, (signageConfig.rotate_seconds || 8) === sec && styles.secPillActive]}
                  onPress={() => setSignageConfig({ ...signageConfig, rotate_seconds: sec })}
                >
                  <Text style={[styles.secPillText, (signageConfig.rotate_seconds || 8) === sec && styles.secPillTextActive]}>
                    {sec}s
                  </Text>
                </TouchableOpacity>
              ))}
            </View>
          </View>

          {/* Ticker bar toggle and text */}
          <View style={[styles.row, { marginTop: 10 }]}>
            <View style={{ flex: 1 }}>
              <Text style={styles.rowTitle}>Banda Notizie / Ticker Scorrevole in Basso</Text>
              <Text style={styles.hint}>Messaggi promozionali, offerte del giorno o avvisi allergeni</Text>
            </View>
            <Switch
              value={signageConfig.ticker_enabled !== false}
              onValueChange={(v) => setSignageConfig({ ...signageConfig, ticker_enabled: v })}
              trackColor={{ false: '#CBD5E1', true: '#0F766E' }}
            />
          </View>

          {signageConfig.ticker_enabled !== false && (
            <TextInput
              style={styles.input}
              value={signageConfig.ticker_text || ''}
              onChangeText={(t) => setSignageConfig({ ...signageConfig, ticker_text: t })}
              placeholder="Testo scorrevole sul fondo della TV..."
            />
          )}

          {/* Auto Reorganize */}
          <View style={[styles.row, { marginTop: 10 }]}>
            <View style={{ flex: 1 }}>
              <Text style={styles.rowTitle}>Smart Auto-Reflow per Piatti Esauriti</Text>
              <Text style={styles.hint}>Riorganizza automaticamente la griglia quando un piatto è esaurito senza lasciare spazi vuoti</Text>
            </View>
            <Switch
              value={signageConfig.auto_reorganize_unavailable !== false}
              onValueChange={(v) => setSignageConfig({ ...signageConfig, auto_reorganize_unavailable: v })}
              trackColor={{ false: '#CBD5E1', true: '#10B981' }}
            />
          </View>
        </View>

        {/* CATEGORY & PRODUCT TIMELINE CONFIGURATOR */}
        <View style={styles.card}>
          <View style={styles.cardHead}>
            <Ionicons name="film-outline" size={20} color="#8B5CF6" />
            <Text style={styles.cardTitle}>Configura Slide & Categorie ({categories.length})</Text>
          </View>

          {/* Category Tabs */}
          <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ gap: 8, paddingVertical: 4 }}>
            {categories.map((cat) => {
              const isSel = currentCategory?.id === cat.id;
              const catCfg = signageConfig.categories_config?.[cat.id];
              const isOff = catCfg?.enabled === false;
              return (
                <TouchableOpacity
                  key={cat.id}
                  style={[styles.catTab, isSel && styles.catTabActive, isOff && { opacity: 0.5 }]}
                  onPress={() => setSelectedCatId(cat.id)}
                >
                  <Text style={[styles.catTabText, isSel && styles.catTabTextActive]}>
                    {cat.name} {isOff ? '(Nascosta)' : ''}
                  </Text>
                </TouchableOpacity>
              );
            })}
          </ScrollView>

          {currentCategory && (
            <View style={styles.catConfigBox}>
              <View style={styles.catConfigHeader}>
                <View>
                  <Text style={styles.catConfigTitle}>Pagina: {currentCategory.name}</Text>
                  <Text style={styles.hint}>{prodsForCurrentCat.length} prodotti presenti in questa categoria</Text>
                </View>
                <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6 }}>
                  <Text style={{ fontSize: 12, fontWeight: '700', color: currentCatConfig.enabled !== false ? '#10B981' : '#EF4444' }}>
                    {currentCatConfig.enabled !== false ? 'ATTIVA SU TV' : 'DISATTIVATA'}
                  </Text>
                  <Switch
                    value={currentCatConfig.enabled !== false}
                    onValueChange={(v) => updateCatConfig(currentCategory.id, { enabled: v })}
                    trackColor={{ false: '#CBD5E1', true: '#10B981' }}
                  />
                </View>
              </View>

              {/* Layout for this category */}
              <Text style={styles.label}>Layout della Pagina ({currentCategory.name})</Text>
              <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ gap: 6 }}>
                {LAYOUT_OPTIONS.map((ly) => (
                  <TouchableOpacity
                    key={ly.id}
                    style={[styles.layoutPill, (currentCatConfig.layout || 'auto') === ly.id && styles.layoutPillActive]}
                    onPress={() => updateCatConfig(currentCategory.id, { layout: ly.id as any })}
                  >
                    <Text style={[styles.layoutPillText, (currentCatConfig.layout || 'auto') === ly.id && styles.layoutPillTextActive]}>
                      {ly.label}
                    </Text>
                  </TouchableOpacity>
                ))}
              </ScrollView>

              {/* Per-Category Theme Override */}
              <Text style={[styles.label, { marginTop: 8 }]}>Tema Grafico per Categoria ({currentCategory.name})</Text>
              <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ gap: 6 }}>
                <TouchableOpacity
                  style={[styles.smallPill, !currentCatConfig.theme && styles.smallPillActive]}
                  onPress={() => updateCatConfig(currentCategory.id, { theme: undefined })}
                >
                  <Text style={[styles.smallPillText, !currentCatConfig.theme && styles.smallPillTextActive]}>
                    Globale ({signageConfig.default_theme || 'chalkboard'})
                  </Text>
                </TouchableOpacity>
                {TEMPLATE_PRESETS.map((t) => (
                  <TouchableOpacity
                    key={t.id}
                    style={[styles.smallPill, currentCatConfig.theme === t.id && styles.smallPillActive]}
                    onPress={() => updateCatConfig(currentCategory.id, { theme: t.id as any })}
                  >
                    <Text style={[styles.smallPillText, currentCatConfig.theme === t.id && styles.smallPillTextActive]}>
                      {t.label}
                    </Text>
                  </TouchableOpacity>
                ))}
              </ScrollView>

              {/* Per-Category Duration Override */}
              <View style={[styles.row, { marginTop: 8 }]}>
                <Text style={styles.label}>Permanenza Categoria:</Text>
                <View style={{ flexDirection: 'row', gap: 6 }}>
                  {[5, 8, 12, 15, 20].map((sec) => (
                    <TouchableOpacity
                      key={sec}
                      style={[styles.secPill, (currentCatConfig.duration_seconds || signageConfig.rotate_seconds || 8) === sec && styles.secPillActive]}
                      onPress={() => updateCatConfig(currentCategory.id, { duration_seconds: sec })}
                    >
                      <Text style={[styles.secPillText, (currentCatConfig.duration_seconds || signageConfig.rotate_seconds || 8) === sec && styles.secPillTextActive]}>
                        {sec}s
                      </Text>
                    </TouchableOpacity>
                  ))}
                </View>
              </View>

              {/* Per-Category Background Video */}
              <View style={{ marginTop: 8 }}>
                <Text style={styles.label}>Video Sfondo Dedicato per Categoria (Opzionale MP4):</Text>
                <TextInput
                  style={styles.input}
                  value={currentCatConfig.bg_video_url || ''}
                  onChangeText={(t) => updateCatConfig(currentCategory.id, { bg_video_url: t })}
                  placeholder="Lascia vuoto per usare il video globale..."
                />
              </View>

              {/* Products in this category list */}
              <Text style={[styles.label, { marginTop: 12 }]}>Piatti della Slide: Dimensione Slot, Animazioni & Badge</Text>
              {prodsForCurrentCat.map((product) => {
                const prodCfg = (currentCatConfig.products_config || {})[product.id] || {};
                const isHero = prodCfg.is_hero || prodCfg.slot_size === 'hero' || prodCfg.slot_size === 'spotlight';
                const anim = prodCfg.animation || 'ken-burns';
                const tag = prodCfg.custom_tag || '';
                const isAvailable = product.available !== false;
                const img = sanitizeImageUri(product.image || '');

                return (
                  <View key={product.id} style={[styles.prodEditorCard, !isAvailable && styles.prodEditorCardUnavailable]}>
                    <View style={styles.prodEditorTop}>
                      {img ? (
                        <ExpoImage source={{ uri: img }} style={styles.prodThumb} contentFit="cover" />
                      ) : (
                        <View style={[styles.prodThumb, { backgroundColor: '#F1F5F9', alignItems: 'center', justifyContent: 'center' }]}>
                          <Text style={{ fontSize: 20 }}>🍽️</Text>
                        </View>
                      )}
                      <View style={{ flex: 1 }}>
                        <Text style={styles.prodEditorName}>{product.name}</Text>
                        <Text style={styles.prodEditorPrice}>€{Number(product.price || 0).toFixed(2)}</Text>
                      </View>

                      {/* Quick Available / Sold-Out Toggle */}
                      <TouchableOpacity
                        style={[styles.soldOutBtn, isAvailable ? styles.soldOutBtnOn : styles.soldOutBtnOff]}
                        onPress={() => { void toggleProductAvailable(product); }}
                        disabled={togglingProdId === product.id}
                      >
                        {togglingProdId === product.id ? (
                          <ActivityIndicator size="small" color="#fff" />
                        ) : (
                          <Text style={styles.soldOutBtnText}>{isAvailable ? 'DISPONIBILE' : 'ESAURITO'}</Text>
                        )}
                      </TouchableOpacity>
                    </View>

                    {/* Slot Size & Hero Button */}
                    <View style={styles.prodEditorControls}>
                      <View style={{ flexDirection: 'row', gap: 6, alignItems: 'center', flexWrap: 'wrap' }}>
                        <Text style={styles.controlLabel}>Dimensione Slot:</Text>
                        {[
                          { id: 'normal', label: 'Standard (1x1)' },
                          { id: 'hero', label: '⭐ Hero Grande (2x1)' },
                          { id: 'spotlight', label: '🔍 Spotlight (2x2)' },
                        ].map((sz) => {
                          const active = (prodCfg.slot_size || (isHero ? 'hero' : 'normal')) === sz.id;
                          return (
                            <TouchableOpacity
                              key={sz.id}
                              style={[styles.smallPill, active && styles.smallPillActive]}
                              onPress={() => updateProdConfig(currentCategory.id, product.id, {
                                slot_size: sz.id as any,
                                is_hero: sz.id === 'hero' || sz.id === 'spotlight',
                              })}
                            >
                              <Text style={[styles.smallPillText, active && styles.smallPillTextActive]}>{sz.label}</Text>
                            </TouchableOpacity>
                          );
                        })}
                      </View>

                      {/* Animation Effect Selector */}
                      <View style={{ flexDirection: 'row', gap: 6, alignItems: 'center', flexWrap: 'wrap', marginTop: 4 }}>
                        <Text style={styles.controlLabel}>Animazione:</Text>
                        {ANIMATION_OPTIONS.map((a) => {
                          const active = anim === a.id;
                          return (
                            <TouchableOpacity
                              key={a.id}
                              style={[styles.smallPill, active && styles.smallPillActive]}
                              onPress={() => updateProdConfig(currentCategory.id, product.id, { animation: a.id as any })}
                            >
                              <Text style={[styles.smallPillText, active && styles.smallPillTextActive]}>{a.label}</Text>
                            </TouchableOpacity>
                          );
                        })}
                      </View>

                      {/* Custom Badge / Sticker */}
                      <View style={{ marginTop: 6 }}>
                        <Text style={styles.controlLabel}>Badge Promozionale:</Text>
                        <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ gap: 6, paddingVertical: 4 }}>
                          <TouchableOpacity
                            style={[styles.badgePill, !tag && styles.badgePillActive]}
                            onPress={() => updateProdConfig(currentCategory.id, product.id, { custom_tag: '' })}
                          >
                            <Text style={[styles.badgePillText, !tag && styles.badgePillTextActive]}>Nessuno</Text>
                          </TouchableOpacity>
                          {BADGE_PRESETS.map((b) => {
                            const active = tag === b;
                            return (
                              <TouchableOpacity
                                key={b}
                                style={[styles.badgePill, active && styles.badgePillActive]}
                                onPress={() => updateProdConfig(currentCategory.id, product.id, { custom_tag: b })}
                              >
                                <Text style={[styles.badgePillText, active && styles.badgePillTextActive]}>{b}</Text>
                              </TouchableOpacity>
                            );
                          })}
                        </ScrollView>
                      </View>
                    </View>
                  </View>
                );
              })}
            </View>
          )}
        </View>
      </ScrollView>

      {/* FULLSCREEN DIGITAL SIGNAGE VISUAL STUDIO MODAL */}
      <Modal visible={editorOpen} animationType="slide" onRequestClose={() => setEditorOpen(false)}>
        <View style={styles.modalContainer}>
          <View style={styles.modalHeader}>
            <TouchableOpacity onPress={() => setEditorOpen(false)} style={styles.modalCloseBtn}>
              <Ionicons name="close" size={24} color="#0F172A" />
            </TouchableOpacity>
            <View style={{ alignItems: 'center' }}>
              <Text style={styles.modalHeaderTitle}>Digital Signage Studio Regia</Text>
              <Text style={{ fontSize: 11, color: '#64748B' }}>
                Anteprima dinamica ({isPortrait ? 'Verticale 9:16' : 'Orizzontale 16:9'})
              </Text>
            </View>
            <TouchableOpacity
              style={styles.modalSaveBtn}
              onPress={async () => {
                await handleSave();
                setEditorOpen(false);
              }}
            >
              <Text style={styles.modalSaveBtnText}>Salva Tutto</Text>
            </TouchableOpacity>
          </View>

          <ScrollView style={styles.modalBody} contentContainerStyle={{ padding: 14, gap: 14 }}>
            {/* LIVE TV MONITOR PREVIEW */}
            <View style={styles.tvMonitorContainer}>
              <View style={styles.tvMonitorHeader}>
                <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6 }}>
                  <Ionicons name="tv" size={16} color="#E2E8F0" />
                  <Text style={styles.tvMonitorTitle}>
                    MONITOR SALA ({isPortrait ? 'VERTICALE 9:16' : 'ORIZZONTALE 16:9'})
                  </Text>
                </View>
                <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
                  <TouchableOpacity
                    style={styles.tvPlayBtn}
                    onPress={() => setPreviewPlaying(!previewPlaying)}
                  >
                    <Ionicons name={previewPlaying ? 'pause' : 'play'} size={14} color="#FFF" />
                    <Text style={styles.tvPlayBtnText}>{previewPlaying ? 'Pausa' : 'Riproduci'}</Text>
                  </TouchableOpacity>
                  <TouchableOpacity
                    style={styles.tvNextBtn}
                    onPress={() => setActivePreviewCatIndex((prev) => (prev + 1) % (categories.length || 1))}
                  >
                    <Ionicons name="play-skip-forward" size={14} color="#FFF" />
                  </TouchableOpacity>
                </View>
              </View>

              {/* TV Screen Frame */}
              <View style={[styles.tvScreen, isPortrait && styles.tvScreenPortrait]}>
                {/* Top Queue Calling */}
                {signageConfig.mode !== 'products' && (
                  <View style={styles.tvQueueStrip}>
                    <Text style={styles.tvLogoText}>TOTEM FAST FOOD</Text>
                    <View style={styles.tvCallPill}>
                      <Text style={styles.tvCallLabel}>IN CHIAMATA</Text>
                      <Text style={styles.tvCallNumber}>#42</Text>
                    </View>
                    <Text style={styles.tvClock}>12:45</Text>
                  </View>
                )}

                {/* Category Banner */}
                {categories.length > 0 && (
                  <View style={styles.tvCatBanner}>
                    <Text style={styles.tvCatKicker}>CATEGORIA</Text>
                    <Text style={styles.tvCatTitle}>
                      {categories[activePreviewCatIndex % categories.length]?.name || 'MENU'}
                    </Text>
                  </View>
                )}

                {/* Cards Preview Grid */}
                <View style={[styles.tvGridPreview, isPortrait && { flexDirection: 'column' }]}>
                  {products
                    .filter((p) => {
                      const curCat = categories[activePreviewCatIndex % categories.length];
                      return curCat && String(p.category_id) === String(curCat.id) && p.available !== false;
                    })
                    .slice(0, isPortrait ? 6 : 8)
                    .map((p, idx) => {
                      const curCat = categories[activePreviewCatIndex % categories.length];
                      const prodCfg = (curCat && signageConfig.categories_config?.[curCat.id]?.products_config?.[p.id]) || {};
                      const isHero = prodCfg.is_hero || idx === 0;
                      return (
                        <View key={p.id || idx} style={[styles.tvCardPreview, isHero && styles.tvCardHero]}>
                          {prodCfg.custom_tag ? (
                            <View style={styles.tvTagPill}>
                              <Text style={styles.tvTagPillText}>{prodCfg.custom_tag}</Text>
                            </View>
                          ) : null}
                          <Text style={{ fontSize: 22 }}>🍽️</Text>
                          <Text style={styles.tvCardName} numberOfLines={1}>{p.name}</Text>
                          <Text style={styles.tvCardPrice}>€{Number(p.price || 0).toFixed(2)}</Text>
                        </View>
                      );
                    })}
                </View>

                {/* Bottom Ticker */}
                {signageConfig.ticker_enabled && (
                  <View style={styles.tvTickerPreview}>
                    <Text style={styles.tvTickerText} numberOfLines={1}>
                      {signageConfig.ticker_text || 'Offerte in corso...'}
                    </Text>
                  </View>
                )}
              </View>
            </View>
          </ScrollView>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#F8FAFC' },
  content: { flex: 1 },
  scroll: { padding: 14, gap: 12, paddingBottom: 40 },
  headerSyncBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    backgroundColor: '#CCFBF1',
    paddingHorizontal: 10,
    paddingVertical: 7,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#99F6E4',
  },
  headerSyncBtnText: {
    color: '#0F766E',
    fontWeight: '800',
    fontSize: 12,
  },
  headerSaveBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    backgroundColor: '#0F766E',
    paddingHorizontal: 12,
    paddingVertical: 7,
    borderRadius: 8,
  },
  headerSaveBtnText: {
    color: '#FFFFFF',
    fontWeight: '800',
    fontSize: 12,
  },
  btnOpenStudio: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor: '#1E1B4B',
    padding: 16,
    borderRadius: 14,
    shadowColor: '#1E1B4B',
    shadowOpacity: 0.25,
    shadowOffset: { width: 0, height: 4 },
    shadowRadius: 8,
    elevation: 3,
  },
  btnOpenStudioLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    flex: 1,
  },
  studioIconCircle: {
    width: 44,
    height: 44,
    borderRadius: 12,
    backgroundColor: '#6366F1',
    alignItems: 'center',
    justifyContent: 'center',
  },
  btnOpenStudioTitle: {
    fontSize: 15,
    fontWeight: '900',
    color: '#FFFFFF',
  },
  btnOpenStudioSubtitle: {
    fontSize: 11,
    color: '#C7D2FE',
    marginTop: 2,
    lineHeight: 15,
  },
  card: { backgroundColor: '#FFF', borderRadius: 14, padding: 14, borderWidth: 1, borderColor: '#E2E8F0', gap: 8 },
  cardHead: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  cardTitle: { fontSize: 14, fontWeight: '800', color: '#0F172A', flex: 1 },
  url: { fontSize: 12, fontWeight: '700', color: '#0F766E', backgroundColor: '#F0FDFA', padding: 8, borderRadius: 8, fontFamily: Platform.OS === 'ios' ? 'Courier' : 'monospace' },
  qrCode: { width: 140, height: 140, alignSelf: 'center', marginVertical: 4 },
  urlActionsRow: { flexDirection: 'row', gap: 8, flexWrap: 'wrap' },
  ghost: { flexDirection: 'row', alignItems: 'center', gap: 6, borderWidth: 1, borderColor: '#CBD5E1', borderRadius: 8, paddingHorizontal: 10, paddingVertical: 6 },
  ghostText: { fontSize: 12, fontWeight: '700', color: '#1E293B' },
  label: { fontSize: 12, fontWeight: '700', color: '#334155', marginTop: 4 },
  orientBtn: {
    flex: 1,
    padding: 12,
    borderRadius: 10,
    backgroundColor: '#F8FAFC',
    borderWidth: 1,
    borderColor: '#E2E8F0',
  },
  orientBtnActive: {
    backgroundColor: '#0F766E',
    borderColor: '#0F766E',
  },
  orientBtnText: {
    fontSize: 12,
    fontWeight: '800',
    color: '#1E293B',
  },
  orientBtnTextActive: {
    color: '#FFFFFF',
  },
  orientBtnDesc: {
    fontSize: 11,
    color: '#64748B',
    marginTop: 2,
  },
  orientBtnDescActive: {
    color: '#CCFBF1',
  },
  row: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  rowTitle: { fontSize: 13, fontWeight: '700', color: '#1E293B' },
  hint: { fontSize: 11, color: '#64748B' },
  input: { borderWidth: 1, borderColor: '#E2E8F0', borderRadius: 8, paddingHorizontal: 10, height: 40, backgroundColor: '#F8FAFC', fontSize: 13 },
  themePill: { flexDirection: 'row', alignItems: 'center', gap: 6, paddingHorizontal: 12, paddingVertical: 8, borderRadius: 8, backgroundColor: '#F1F5F9', borderWidth: 1, borderColor: '#E2E8F0' },
  themePillActive: { backgroundColor: '#0F172A', borderColor: '#0F172A' },
  themePillText: { fontSize: 12, fontWeight: '700', color: '#475569' },
  themePillTextActive: { color: '#FFF' },
  secPill: { paddingHorizontal: 10, paddingVertical: 6, borderRadius: 6, backgroundColor: '#F1F5F9', borderWidth: 1, borderColor: '#E2E8F0' },
  secPillActive: { backgroundColor: '#0F766E', borderColor: '#0F766E' },
  secPillText: { fontSize: 12, fontWeight: '700', color: '#475569' },
  secPillTextActive: { color: '#FFF' },
  catTab: { paddingHorizontal: 12, paddingVertical: 8, borderRadius: 8, backgroundColor: '#F1F5F9', borderWidth: 1, borderColor: '#E2E8F0' },
  catTabActive: { backgroundColor: '#8B5CF6', borderColor: '#8B5CF6' },
  catTabText: { fontSize: 12, fontWeight: '700', color: '#475569' },
  catTabTextActive: { color: '#FFF' },
  catConfigBox: { backgroundColor: '#F8FAFC', borderWidth: 1, borderColor: '#E2E8F0', borderRadius: 12, padding: 12, marginTop: 8, gap: 8 },
  catConfigHeader: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', borderBottomWidth: 1, borderBottomColor: '#E2E8F0', paddingBottom: 8 },
  catConfigTitle: { fontSize: 14, fontWeight: '800', color: '#0F172A' },
  layoutPill: { paddingHorizontal: 10, paddingVertical: 6, borderRadius: 6, backgroundColor: '#FFFFFF', borderWidth: 1, borderColor: '#E2E8F0' },
  layoutPillActive: { backgroundColor: '#8B5CF6', borderColor: '#8B5CF6' },
  layoutPillText: { fontSize: 11, fontWeight: '700', color: '#475569' },
  layoutPillTextActive: { color: '#FFF' },
  prodEditorCard: { backgroundColor: '#FFFFFF', borderWidth: 1, borderColor: '#E2E8F0', borderRadius: 10, padding: 10, gap: 6, marginTop: 4 },
  prodEditorCardUnavailable: { opacity: 0.6, borderColor: '#FECDD3' },
  prodEditorTop: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  prodThumb: { width: 44, height: 44, borderRadius: 8 },
  prodEditorName: { fontSize: 13, fontWeight: '800', color: '#0F172A' },
  prodEditorPrice: { fontSize: 12, fontWeight: '700', color: '#0F766E' },
  soldOutBtn: { paddingHorizontal: 8, paddingVertical: 4, borderRadius: 6 },
  soldOutBtnOn: { backgroundColor: '#ECFDF5', borderWidth: 1, borderColor: '#A7F3D0' },
  soldOutBtnOff: { backgroundColor: '#FEE2E2', borderWidth: 1, borderColor: '#FECDD3' },
  soldOutBtnText: { fontSize: 10, fontWeight: '800', color: '#0F172A' },
  prodEditorControls: { backgroundColor: '#F8FAFC', borderRadius: 8, padding: 8, gap: 4 },
  controlLabel: { fontSize: 11, fontWeight: '700', color: '#475569' },
  smallPill: { paddingHorizontal: 8, paddingVertical: 4, borderRadius: 6, backgroundColor: '#FFFFFF', borderWidth: 1, borderColor: '#E2E8F0' },
  smallPillActive: { backgroundColor: '#0F766E', borderColor: '#0F766E' },
  smallPillText: { fontSize: 11, fontWeight: '700', color: '#475569' },
  smallPillTextActive: { color: '#FFF' },
  badgePill: { paddingHorizontal: 8, paddingVertical: 4, borderRadius: 6, backgroundColor: '#FFFFFF', borderWidth: 1, borderColor: '#E2E8F0' },
  badgePillActive: { backgroundColor: '#F59E0B', borderColor: '#F59E0B' },
  badgePillText: { fontSize: 10, fontWeight: '800', color: '#475569' },
  badgePillTextActive: { color: '#FFF' },
  modalContainer: { flex: 1, backgroundColor: '#0F172A' },
  modalHeader: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 16, paddingVertical: 12, backgroundColor: '#1E293B', borderBottomWidth: 1, borderBottomColor: '#334155' },
  modalCloseBtn: { padding: 6 },
  modalHeaderTitle: { fontSize: 15, fontWeight: '800', color: '#FFFFFF' },
  modalSaveBtn: { backgroundColor: '#10B981', paddingHorizontal: 14, paddingVertical: 8, borderRadius: 8 },
  modalSaveBtnText: { color: '#FFFFFF', fontWeight: '800', fontSize: 13 },
  modalBody: { flex: 1 },
  tvMonitorContainer: { backgroundColor: '#1E293B', borderRadius: 14, padding: 12, gap: 10, borderWidth: 1, borderColor: '#334155' },
  tvMonitorHeader: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  tvMonitorTitle: { fontSize: 12, fontWeight: '800', color: '#E2E8F0' },
  tvPlayBtn: { flexDirection: 'row', alignItems: 'center', gap: 4, backgroundColor: '#334155', paddingHorizontal: 8, paddingVertical: 4, borderRadius: 6 },
  tvPlayBtnText: { color: '#FFF', fontSize: 11, fontWeight: '700' },
  tvNextBtn: { backgroundColor: '#334155', padding: 6, borderRadius: 6 },
  tvScreen: { backgroundColor: '#020617', borderRadius: 10, padding: 12, gap: 8, borderWidth: 1, borderColor: '#1E293B', minHeight: 320 },
  tvScreenPortrait: { minHeight: 480, maxWidth: 360, alignSelf: 'center', width: '100%' },
  tvQueueStrip: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', backgroundColor: '#0F172A', padding: 8, borderRadius: 8 },
  tvLogoText: { fontSize: 12, fontWeight: '900', color: '#F8FAFC' },
  tvCallPill: { flexDirection: 'row', alignItems: 'center', gap: 4, backgroundColor: '#DC2626', paddingHorizontal: 8, paddingVertical: 2, borderRadius: 4 },
  tvCallLabel: { fontSize: 9, fontWeight: '800', color: '#FFF' },
  tvCallNumber: { fontSize: 12, fontWeight: '900', color: '#FFF' },
  tvClock: { fontSize: 12, fontWeight: '800', color: '#94A3B8' },
  tvCatBanner: { backgroundColor: '#1E1B4B', padding: 8, borderRadius: 6 },
  tvCatKicker: { fontSize: 9, fontWeight: '800', color: '#818CF8' },
  tvCatTitle: { fontSize: 14, fontWeight: '900', color: '#FFFFFF' },
  tvGridPreview: { flexDirection: 'row', flexWrap: 'wrap', gap: 6 },
  tvCardPreview: { flex: 1, minWidth: '45%', backgroundColor: '#1E293B', borderRadius: 8, padding: 8, alignItems: 'center', gap: 2, borderWidth: 1, borderColor: '#334155' },
  tvCardHero: { minWidth: '95%', backgroundColor: '#312E81', borderColor: '#4338CA' },
  tvCardName: { fontSize: 12, fontWeight: '800', color: '#F8FAFC' },
  tvCardPrice: { fontSize: 11, fontWeight: '800', color: '#34D399' },
  tvTagPill: { position: 'absolute', top: 4, right: 4, backgroundColor: '#D97706', paddingHorizontal: 4, paddingVertical: 2, borderRadius: 4 },
  tvTagPillText: { fontSize: 8, fontWeight: '800', color: '#FFF' },
  tvTickerPreview: { backgroundColor: '#0F172A', padding: 6, borderRadius: 4 },
  tvTickerText: { fontSize: 10, color: '#FCD34D', fontWeight: '700' },
});
